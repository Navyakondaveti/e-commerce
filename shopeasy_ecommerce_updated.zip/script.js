const products=[
{id:1,name:"Smart Watch",price:1999,category:"Electronics",image:"https://images.unsplash.com/photo-1523275335684-37898b6baf30"},
{id:2,name:"Headphones",price:1499,category:"Electronics",image:"https://images.unsplash.com/photo-1505740420928-5e560c06d30e"},
{id:3,name:"Running Shoes",price:2499,category:"Footwear",image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff"},
{id:4,name:"Backpack",price:999,category:"Accessories",image:"https://images.unsplash.com/photo-1553062407-98eeb64c6a62"},
{id:5,name:"Sunglasses",price:799,category:"Accessories",image:"https://images.unsplash.com/photo-1511499767150-a48a237f0083"},
{id:6,name:"T-Shirt",price:599,category:"Fashion",image:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab"}];
let cart=[];
function displayProducts(list=products){const c=document.getElementById("productContainer");c.innerHTML="";list.forEach(p=>{c.innerHTML+=`<div class="product"><img src="${p.image}" alt="${p.name}"><h3>${p.name}</h3><p class="price">₹${p.price}</p><button class="add-btn" onclick="addToCart(${p.id})">Add to Cart</button></div>`})}
function addToCart(id){let p=products.find(x=>x.id===id),item=cart.find(x=>x.id===id);item?item.quantity++:cart.push({...p,quantity:1});updateCart();alert(p.name+" added to cart!")}
function updateCart(){let box=document.getElementById("cartItems"),total=0,count=0;box.innerHTML="";cart.forEach(i=>{total+=i.price*i.quantity;count+=i.quantity;box.innerHTML+=`<div class="cart-item"><div><h4>${i.name}</h4><p>₹${i.price}</p></div><div class="quantity"><button onclick="changeQuantity(${i.id},-1)">−</button> <span>${i.quantity}</span> <button onclick="changeQuantity(${i.id},1)">+</button><button class="remove" onclick="removeFromCart(${i.id})">🗑️</button></div></div>`});document.getElementById("cartCount").textContent=count;document.getElementById("cartTotal").textContent=total}
function changeQuantity(id,n){let i=cart.find(x=>x.id===id);if(i)i.quantity+=n;if(i&&i.quantity<=0)removeFromCart(id);updateCart()}
function removeFromCart(id){cart=cart.filter(x=>x.id!==id);updateCart()}
function toggleCart(){document.getElementById("cart").classList.toggle("active")}
function searchProducts(){let q=document.getElementById("searchInput").value.toLowerCase();displayProducts(products.filter(p=>p.name.toLowerCase().includes(q)||p.category.toLowerCase().includes(q)))}
function filterCategory(cat){displayProducts(products.filter(p=>p.category===cat));document.getElementById("featured").scrollIntoView()}
function scrollToProducts(){document.getElementById("featured").scrollIntoView()}
function subscribe(){let e=document.getElementById("emailInput").value;if(!e){alert("Please enter your email.");return}alert("Thanks for subscribing! 🎉");document.getElementById("emailInput").value=""}
function checkout(){if(!cart.length){alert("Your cart is empty!");return}alert("Order placed successfully! 🎉");cart=[];updateCart();toggleCart()}
displayProducts();updateCart();